<?php
if(isset($_GET['hash'])){
$hash=@$_GET['hash'];
if(strtolower($hash)==='251471f34244cb6cd61f6b64c63f7b1a'){
echo "ChunQiuGame";
}else{
echo "No Result.";
}
die();
}
?>

<html>
<head>
<title>HashTool</title>
<link rel="stylesheet" href="Document_files/bootstrap.min.css">
<meta charset="utf-8">
</head>
<body>
<div>

<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>HashTool</legend>

<!-- Text input-->
<div class="form-group">
<label class="col-md-4 control-label" for="textinput">HASH</label>
<div class="col-md-4">
<input id="textinput" name="hash" placeholder="Input a md5" class="form-control input-md" type="text">
<br>
<button id="singlebutton" class="btn btn-primary">Submit</button>
</div>
</div>

</fieldset>
</form>

</div>
</body>
</html>