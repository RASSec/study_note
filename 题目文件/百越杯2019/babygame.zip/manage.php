<?php
session_start();
$conn = mysqli_connect('localhost','web3','root_123!@#','web3') or die('Unale to connect');
if (!get_magic_quotes_gpc()){
foreach($_POST as $key => $value){
$_POST[$key] = addslashes($value);
}
foreach($_GET as $key => $value){
$_GET[$key] = addslashes($value);
}
}
if(isset($_GET['action']) && $_GET['action'] == 'login'){
if(isset($_SESSION['islogin']) && $_SESSION['islogin']){
header('Location: manage.php?action=showuser');
die();
}
if(isset($_POST['username']) && isset($_POST['password'])){
$username = mysqli_real_escape_string($conn,$_POST['username']);
$password = md5($_POST['password']);
$sql = "SELECT * FROM users WHERE username = '$username' and password = '$password'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
if($row){
$_SESSION['islogin'] = true;
$_SESSION['username'] = $row[1];
if($_SESSION['username'] === 'admin')
{
header('Location: manage.php?action=admin');
die();
}
else
{
header('Location: manage.php?action=showuser');
die();
}
}else{
die('<script>alert("something error,plz again");window.location="index.html";</script>');
}
}
die();
} else if(isset($_GET['action']) && $_GET['action'] == 'register'){
if(isset($_POST['username']) && isset($_POST['password'])){
$username = mysqli_real_escape_string($conn,$_POST['username']);
$password = md5($_POST['password']);
$sql = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
if($row){
die('<script>alert("user exists!!!");window.location="index.html";</script>');
}
$sql = "INSERT INTO users(username, password) VALUES ('$username', '$password')";
$result = mysqli_query($conn,$sql);
$id = mysqli_insert_id($conn);
if(!$result){
die('<script>alert("something error with db,plz contact with me");window.location="index.html";</script>');
}
$flag = "flag{" . md5($username . $password) . "}";
$sql = "INSERT INTO flags(username, flag, msgid) VALUES ('$username', '$flag', '1')";
$result = mysqli_query($conn,$sql);
if(!$result){
die('<script>alert("something error with db,plz contact with me");window.location="index.html";</script>');
}
$sql = "SELECT * FROM users WHERE id = $id";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
if($row){
$_SESSION['islogin'] = true;
$_SESSION['username'] = $row[1];
die('<script>alert("register success!");window.location="manage.php?action=showuser";</script>');
}else{
die('error');
}
}
die();
} else if(isset($_GET['action']) && $_GET['action'] == 'showuser'){
if(!isset($_SESSION['islogin'])){
header('Location: index.html');
die();
}
echo "<h1>Hello," . $_SESSION['username'] . "!</h1>";
echo "<h2>Here is your flags</h2>";
$sql = "SELECT * FROM flags WHERE username = '" . $_SESSION['username'] . "'";
$result = mysqli_query($conn,$sql);
if($result){
while( $row = mysqli_fetch_row($result) ){
$msgid = $row[3];
echo "<a href='manage.php?msgid=$msgid'>here is your flag!</a>";
}
}
die();
}
else if(isset($_GET['action']) && $_GET['action'] == 'admin'){
if(!isset($_SESSION['islogin']))
{
header('Location: index.html');
die();
}
if($_SESSION['username'] !== 'admin')
{
header('Location: index.html');
die();
}
if(isset($_POST['content']) and $_POST['content'] != "")
{
$xml = stripslashes($_POST['content']);
$dom = new DOMDocument;
$dom->preserveWhiteSpace = false;
$dom->formatOutput = true;
$dom->loadXML($xml);
$dom->xinclude();
if($dom->saveXML())
{
echo "<div class=\"container\">";
echo $dom->saveXML();
echo "</div>";
}
}
else
{
die('plz post content and you may need xxe');
}
}

if(!isset($_SESSION['islogin'])){
header('Location: index.html');
die();
}

if(isset($_GET['msgid'])){
if(!isset($_SESSION['islogin'])){
header('Location: index.html');
die();
}
$username = $_SESSION['username'];
$msgid = mysqli_real_escape_string($conn,$_GET['msgid']);
$sql = "SELECT * FROM flags WHERE username = '$username' and msgid = '$msgid'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_row($result);
if($row){
$flag = $row[2];
echo $flag;
die();
}
die();
}